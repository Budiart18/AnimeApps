package com.aeryz.core.utils

object Constant {
    const val SPLASH_SCREEN_DELAY : Long = 2000
}