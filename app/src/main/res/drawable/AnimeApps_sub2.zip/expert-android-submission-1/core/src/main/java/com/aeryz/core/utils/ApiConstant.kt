package com.aeryz.core.utils

object ApiConstant {
   const val BASE_URL = "https://api.jikan.moe/v4/"
   const val GET_ALL_ANIME = "anime"
   const val GET_ANIME_ID = "anime/{id}/full"
}